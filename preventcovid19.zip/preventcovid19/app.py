import os, sys
from flask import Flask, request
from wit import Wit
from pymessenger import Bot

app = Flask(__name__)

access_token = "5MAJJIOD247MERMGJPK6QYCJ5YCBLW4H"

PAGE_ACCESS_TOKEN = "EAANZA5ZBBU3j8BAMdKYrt8nk8ZC9o1g0dwEV56S8risTrQ6VtiZCNe2YsfvQPASrv2joM3d0qZB5krwacFJVObk7RKPdo941wxkxg2brE6SycE5omz7965dKiCHiBzVX0hwgn2uHmqVQA6hGiddaVQT9pjru9fP0aSNFhBOOKlB0DehMsZB25fhTflrqzVmIMZD"

client = Wit(access_token = access_token)

bot = Bot(PAGE_ACCESS_TOKEN)

def wit_response(message_text):
	resp = client.message(message_text)
	entity = None
	value = None

	try:
		entity = list(resp['entities'])[0]
		value = resp['entities'][entity][0]['value']
	except:
		pass

	return(entity, value)

@app.route('/', methods=['GET'])
def verify():
    # Webhook verification
    if request.args.get("hub.mode") == "subscribe" and request.args.get("hub.challenge"):
        if not request.args.get("hub.verify_token") == "hello":
            return "verification token mismatch", 403
        return request.args["hub.challenge"], 200
    return "Hello World", 200

@app.route('/', methods=["POST"])
def webhook():
	data = request.get_json()
	log(data)

	if data['object'] == 'page':
		for entry in data['entry']:
			for messaging_event in entry['messaging']:

				#IDs
				sender_id = messaging_event['sender']['id']
				recipient_id = messaging_event['recipient']['id']

				if messaging_event.get('message'):
					if 'text' in messaging_event['message']:
						messaging_text = messaging_event['message']['text']
					else:
						messaging_text = 'no text'

					response = None
					entity, value = wit_response(messaging_text)

					if entity == 'news:news':
						response = "Got that! Here is the latest news you wanted.".format(str(value))
					elif entity == "Country:Country":
						response = "Ok. You wanted the insight for {0}. I will send you the top headline news for {0}".format(str(value))
					elif entity == 'Virus_Subject:Virus_Subject':
					 	response = "Alright, here is the latest news for {}".format(str(value))
					elif entity == "quantity:quantity":
						response = "That's a great question! I will get the {0} of Covid-19 cases and update you in a bit".format(str(value))
					elif entity == 'Greeting:Greeting':
					 	response = "Hey there! Hope you are fine. What can I help you with?"
					elif entity == 'Ending:Ending':
					 	response = "Alright. Glad that I could help. \n\nWould you mind giving me a score based on how well I did?\n\nScore range from 1-5. \n\n1 - Bad\n 5 - Excellent \n\nPress '6' to exit the chat."
					elif entity == 'go_out:go_out':
					 	response = "Alright! You may now exit the chat. See you soon! :)"
					elif entity == 'improve:improve':
					 	response = "Oh I see. Are there any feedback for me to help improve on your experience next time we have a chat?"
					elif entity == 'feedback:feedback':
					 	response = "Thank you so much! We will review your feedback as soon as we can. You may exit the chat now. See you soon! :)"
					elif entity == 'finish:finish':
					 	response = "Thank you so much! You may exit the chat now. See you soon! :)"

					if response == None:
						response = "Sorry, please try again."

					bot.send_text_message(sender_id, response)

	return "ok", 200


def log(message):
	print(message)
	sys.stdout.flush()

if __name__ == "__main__":
    app.run(debug = True, port = 80)